<?= $this->extend('admin/layout/main') ?>

<?= $this->section('content') ?>

<?= $this->endSection() ?>