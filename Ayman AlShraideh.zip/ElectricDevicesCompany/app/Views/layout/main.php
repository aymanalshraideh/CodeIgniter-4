<?= $this->include('layout/nav') ?>
<?= $this->renderSection('content') ?>
<?= $this->include('layout/footer') ?>
